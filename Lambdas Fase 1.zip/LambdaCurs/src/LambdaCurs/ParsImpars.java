package LambdaCurs;


public interface ParsImpars {
	void operar(int numero);
}

