package FunInterface;

public interface Fase2 {
	public abstract void  getPiValue();
}
