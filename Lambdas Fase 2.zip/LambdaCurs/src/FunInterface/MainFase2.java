package FunInterface;
import java.util.function.*;

public class MainFase2 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Double valorPi=3.1416;
		Fase2 i = () -> System.out.println(valorPi*3);
		i.getPiValue();
	}
}
